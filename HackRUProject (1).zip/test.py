from tkinter import *
import tkinter as tk
import tkinter.font as Font

r = tk.Tk()
print(list(tk.font.families()))

